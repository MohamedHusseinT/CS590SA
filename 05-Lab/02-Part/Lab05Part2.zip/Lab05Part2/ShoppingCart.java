package Lab05Part2;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private String id;
    private List<CartLine> items = new ArrayList<>();

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public List<CartLine> getItems() { return items; }
    public void setItems(List<CartLine> items) { this.items = items; }

    public void addToCart(Product product, int quantity) {
        items.add(new CartLine(product.getProductNumber(), quantity));
    }
}
