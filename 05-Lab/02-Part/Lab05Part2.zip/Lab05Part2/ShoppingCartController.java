package Lab05Part2;

public class ShoppingCartController {
    @Autowired private ShoppingCartRepository repo;
    @Autowired private ProductRepository productRepo;

    @PostMapping("/add")
    public ShoppingCart addToCart(@RequestParam String cartId, @RequestParam String productId, @RequestParam int qty) {
        ShoppingCart cart = repo.findById(cartId).orElse(new ShoppingCart());
        Product product = productRepo.findById(productId).orElseThrow();
        cart.addToCart(product, qty);
        return repo.save(cart);
    }

    @GetMapping("/{id}")
    public ShoppingCart getCart(@PathVariable String id) {
        return repo.findById(id).orElse(null);
    }
}
