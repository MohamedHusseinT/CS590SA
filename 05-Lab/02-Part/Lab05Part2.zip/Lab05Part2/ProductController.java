package Lab05Part2;

@RestController
@RequestMapping("/product")
public class ProductController {
    @Autowired
    private ProductRepository repo;

    @PostMapping
    public Product addProduct(@RequestBody Product p) {
        return repo.save(p);
    }

    @GetMapping("/{id}")
    public Product getProduct(@PathVariable String id) {
        return repo.findById(id).orElse(null);
    }
}
