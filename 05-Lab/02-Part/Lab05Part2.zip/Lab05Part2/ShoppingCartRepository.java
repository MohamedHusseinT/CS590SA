package Lab05Part2;

public interface ShoppingCartRepository extends MongoRepository<ShoppingCart, String> {

}
