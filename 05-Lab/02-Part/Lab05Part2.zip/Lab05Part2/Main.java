package Lab05Part2;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        SpringApplication.run(WebshopClient.class, args);
    }

    @Bean
    CommandLineRunner run() {
        return args -> {
            RestTemplate rest = new RestTemplate();

            // 1. Add Product
            Product p = new Product();
            p.setProductNumber("P001");
            p.setName("Keyboard");
            p.setDescription("Mechanical Keyboard");
            p.setPrice(120.0);
            Product saved = rest.postForObject("http://localhost:8080/product", p, Product.class);

            // 2. Get Product
            Product fetched = rest.getForObject("http://localhost:8080/product/" + saved.getId(), Product.class);
            System.out.println("Fetched: " + fetched.getName());

            // 3. Add to Cart
            String url = "http://localhost:8080/shoppingcart/add?cartId=1&productId=" + fetched.getId() + "&qty=2";
            ShoppingCart cart = rest.postForObject(url, null, ShoppingCart.class);

            // 4. Get Cart
            ShoppingCart retrieved = rest.getForObject("http://localhost:8080/shoppingcart/1", ShoppingCart.class);
            System.out.println("Cart contains: " + retrieved.getItems().size() + " items.");
        };
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}