package Lab05Part2;

public interface ProductRepository extends MongoRepository<Product, String> {
}
